Data was extracted from:

https://databank.worldbank.org/reports.aspx?source=world-development-indicators#

Information for year 2019.

These are the variables extracted:
SP.DYN.LE00.IN	CC BY-4.0	Life expectancy at birth, total (years)		Life expectancy at birth indicates the number of years a newborn infant would live if prevailing patterns of mortality at the time of its birth were to stay the same throughout its life.
NY.GDP.PCAP.CD	CC BY-4.0	GDP per capita (current US$)		GDP per capita is gross domestic product divided by midyear population. GDP is the sum of gross value added by all resident producers in the economy plus any product taxes and minus any subsidies not included in the value of the products. It is calculated without making deductions for depreciation of fabricated assets or for depletion and degradation of natural resources. Data are in current U.S. dollars.
